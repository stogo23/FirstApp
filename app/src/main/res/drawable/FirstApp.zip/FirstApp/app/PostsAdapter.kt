package com.stogo.firstapp
import android.widget.ArrayAdapter
class PostsAdapter {
}